
# class mutexGuard(object):
#     def __init__(self,mutex):
#         self.mutex = mutex
#         self.mutex.enter()
#         pass
#     def __del__(self):
#         self.mutex.leave()

