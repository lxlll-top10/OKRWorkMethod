
#状态枚举
import string

from PyQt5.QtGui import QPainter
from dateutil import parser

from modules.Settings import *
from stringKey import *

dates = {
    'Sun': '星期天', 'Mon': '星期一', 'Tues': '星期二', 'Wed': '星期三',
    'Thurs': '星期四', 'Fri': '星期五', 'Sat': '星期六'}
states = {
    STATE_INIT:SK_STATE_INIT,
    STATE_UNOK:SK_STATE_UNOK,
    STATE_OK:SK_STATE_OK,
    STATE_STOP:SK_STATE_STOP,
    STATE_DELAY:SK_STATE_DELAY
}
#stateList = [STATE_INIT,STATE_UNOK,STATE_OK,STATE_STOP,STATE_DELAY]
stateList = [STATE_UNOK,STATE_OK]
def getStateStringKey(state):
    stateStr = states.get(state,'')
    return stateStr

def getDateStr(dateTime,hour = True,isShow = False):
    curDateStr = dateTime.strftime("%Y-%m-%d %H:%M:%S")
    if curDateStr == DATE_LONG:
        curDateStr = SK_SET_END_DATE if isShow == False else SK_NO_END_DATE
    else:
        if hour == False:
            curDateStr = dateTime.strftime("%Y-%m-%d")
    return curDateStr
def getTimeStr(dateTime):
    curTimeStr = dateTime.strftime("%H:%M:%S")
    return curTimeStr

def getDateTimeFromStr(dateStr):
    if dateStr != SK_SET_END_DATE:
        return parser.parse(dateStr)
    else:
        return parser.parse(DATE_LONG)

dateLenStrList = [SK_DAY_ONE,SK_DAY_TWO,SK_DAY_THREE,SK_DAY_FOUR,SK_DAY_FIVE,SK_DAY_SIX,SK_WEEK_ONE,SK_WEEK_TWO,SK_WEEK_THREE,SK_WEEK_FOUR]

dateLens = {
    SK_DAY_ONE:24,
    SK_DAY_TWO:48,
    SK_DAY_THREE:72,
    SK_DAY_FOUR:96,
    SK_DAY_FIVE:120,
    SK_DAY_SIX:144,
    SK_WEEK_ONE:168,
    SK_WEEK_TWO:336,
    SK_WEEK_THREE:504,
    SK_WEEK_FOUR:672
}
def getRemindDateLen(dateLenStr):
    return dateLens.get(dateLenStr,24)

def getRemindDateStr(dateLen):
    curDateStr = SK_DAY_ONE
    for dateLenItem in dateLens:
        if dateLen == getRemindDateLen(dateLenItem):
            curDateStr = dateLenItem
    return curDateStr




#字符串处理相关

def getStrCount(str):
    '''找出字符串中的中英文、空格、数字、标点符号个数'''
    count_en = count_dg = count_sp = count_zh = count_pu = 0
    for s in str:
        # 英文
        if s in string.ascii_letters:
            count_en += 1
        # 数字
        elif s.isdigit():
            count_dg += 1
        # 空格
        elif s.isspace():
            count_sp += 1
        # 中文，除了英文之外，剩下的字符认为就是中文
        elif s.isalpha():
            count_zh += 1
        # 特殊字符
        else:
            count_pu += 1

    allCount = count_en + count_dg + count_zh
    return allCount
def cutStrRange(str,start,end):
    realStart = start
    realEnd = end
    if start < 0:
        realStart = 0
    if end > len(str):
        realEnd = len(str)
    return str[realStart:realEnd]

def getNameFromFullName(fullName):
    if fullName != MANAGER_USER:
        return cutStrRange(fullName, len(fullName) - 2, len(fullName))
    else:
        return fullName
#检验用户名是否合法
def nameIsLegal(fullName):
    ret = True
    if fullName != MANAGER_USER:
        count_zh = count_dg = 0
        hasDigit = False
        hasZn = False
        for s in fullName:
            # 中文
            if s.isalpha():
                if hasDigit:
                    ret = False
                    break
                else:
                    hasZn = True
                    count_zh += 1
            # 数字
            elif s.isdigit():
                if hasZn == True:
                    hasDigit = True
                    count_dg += 1
                else:
                    ret = False
                    break
            else:
                ret = False
                break
        if ret == True:
            if hasZn == False or count_zh > 4 or count_dg > 2:
                ret = False
    return ret

def passWordIsLegal(passWord):
    ret = True
    if len(passWord) < 6:
        ret = False
    return ret
#宽度计算不准
def strInsertLineChar(srcStr,width,obj,insertChar = '\n'):
    if obj != None:
        p = QPainter(obj)
    else:
        p = QPainter()
    fm = p.fontMetrics()
    index = 1
    start = 0
    detStr = ''
    for s in srcStr:
        curWidth = fm.width(srcStr[start:index])
        if curWidth > width:
            detStr += insertChar
            start = index
        detStr += s
        index += 1
    return detStr

timeType = [{'showData':SK_0_5_HOUR,'taskTime':30},
            {'showData': SK_1_HOUR, 'taskTime': 60},
            {'showData': SK_1_5_HOUR, 'taskTime': 90},
            {'showData': SK_2_HOUR, 'taskTime': 120},
            {'showData': SK_2_5_HOUR, 'taskTime': 150},
            {'showData': SK_3_HOUR, 'taskTime': 180},
            {'showData': SK_3_5_HOUR, 'taskTime': 210},
            {'showData': SK_4_HOUR, 'taskTime': 240},
            {'showData': SK_4_5_HOUR, 'taskTime': 270},
            {'showData': SK_5_HOUR, 'taskTime': 300},
            {'showData': SK_5_5_HOUR, 'taskTime': 330},
            {'showData': SK_6_HOUR, 'taskTime': 360},
            {'showData': SK_6_5_HOUR, 'taskTime': 390},
            {'showData': SK_7_HOUR, 'taskTime': 420},
            {'showData': SK_7_5_HOUR, 'taskTime': 450},
            {'showData': SK_8_HOUR, 'taskTime': 480},
            {'showData': SK_8_5_HOUR, 'taskTime': 510},
            {'showData': SK_9_HOUR, 'taskTime': 540},
            {'showData': SK_9_5_HOUR, 'taskTime': 570},
            {'showData': SK_10_HOUR, 'taskTime': 600},
            {'showData': SK_10_5_HOUR, 'taskTime': 630},
            {'showData': SK_11_HOUR, 'taskTime': 660},
            {'showData': SK_11_5_HOUR, 'taskTime': 690},
            {'showData': SK_12_HOUR, 'taskTime': 720}]

targetOver = [{'showData':SK_TARGET_OK,'targetState':DAILY_OK},
            {'showData': SK_TARGET_UNOK, 'targetState': DAILY_UNOK},
            {'showData': SK_TARGET_NODEAL, 'targetState': DAILY_NODEAL}]

#strInsertLineChar('11111',5,None)
class A(object):
    def __init__(self):
        self.test = 2

    def PrintF(self):
        print(self.test)
    def __del__(self):
        print('A_del_')
class Test(object):
    def __del__(self):
        print('Test_del_')
        print(self.num)
        self.a.PrintF()

        pass
    def __init__(self):
        self.num = 1
        self.a = A()

        pass



