import sys
import logging
from logging import Logger

from modules.Settings import LOG_FOMAT,LOG_DATAFAMAT,LOG_LEVEL,LOG_FILEPATH

class logger(object):
    def __init__(self):
        self._logger = logging.getLogger()
        self.formatter = logging.Formatter(fmt=LOG_FOMAT,datefmt=LOG_DATAFAMAT)
        self._logger.setLevel(LOG_LEVEL)
        #3 设置日志输出
        #3.1 设置日志文件模式
        self._logger.addHandler(self.__get_file_handler(LOG_FILEPATH))
        #3.2 设置终端日志模式
        self._logger.addHandler(self.__get_console_handler())

    def __get_file_handler(self,filename):
        filehandler = logging.FileHandler(filename=filename,encoding='UTF-8')
        filehandler.setFormatter(self.formatter)
        return filehandler
    def __get_console_handler(self):
        consolehandler = logging.StreamHandler(sys.stdout)
        consolehandler.setFormatter(self.formatter)
        return consolehandler
    def logger(self):
        return self._logger
logger: Logger = logger().logger()
if __name__ == '__main__':
    logger.debug("debug")
    logger.info("info")
    logger.error("error")
    logger.critical("critical")
    logger.info("%stest",1)