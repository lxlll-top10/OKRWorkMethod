import os

from bs4 import BeautifulSoup
import base64

from utils.log import logger


def changHTMLImage(htmlData):
    ret = False
    changeFlag = False
    if isinstance(htmlData,list):
        soup = BeautifulSoup(htmlData[0], 'html.parser')
    else:
        soup = BeautifulSoup(htmlData, 'html.parser')
    itemTags = soup.find_all('img')
    for item in itemTags:
        imagePath =item['src'][8:512]
        #print(imagePath)
        if os.path.isfile(imagePath):
            file = open(imagePath,'rb')
            base64Data = base64.b64encode(file.read())
            base64FileData = base64Data.decode()
            file.close()
            item['src'] = 'data:image/jpeg;base64,{}'.format(base64FileData)
            changeFlag = True
        else:
            logger.info("imagePath isn't file：{}".format(imagePath))
            pass
    if isinstance(htmlData, list) and changeFlag == True:
        htmlData[0] = soup.__str__()
        ret = True
    return ret
    pass
