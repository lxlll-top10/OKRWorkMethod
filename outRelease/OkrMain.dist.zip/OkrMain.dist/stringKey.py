
DB_IPADDR = '127.0.0.1'

MEMCHECK_FLAG = False
#登入注册界面
SK_USER_NAME = '通行账号'
SK_REGISTER_USER = "注册帐号"
SK_FORGET_PASSWORD = "忘记密码"
SK_INPUT_USER_AND_PW =  "输入注册的用户名、工号和密码"
SK_REGISTER = '注      册'
SK_LOGIN = '登      录'

#添加设备
SK_ADD_DEVICE = '添加设备'
SK_DEVICE_NAME_TIP = '请输入设备名'
SK_DEVICE_NUMBER_TIP = '请输入设备序列号'
SK_ADD_DEVICE_FAIL = '添加设备失败，请确认当前设备序列号是否已经被添加！'
SK_ADD_DEVICE_FAIL = '添加设备成功，是否继续添加？'
SK_INPUT_USERNAME_TIP = '输入用户名'
SK_INPUT_USENUMBER_TIP = '输入工号'
SK_INPUT_PASSWORD_TIP = '输入密码'

SK_BORROW_DEVICE_SUCC = '设备借用成功！'
SK_RETURN_DEVICE_TIP = '设备实体是否归还？'
SK_RETURN_DEVICE_WARN = '当前用户没有归还设备的权限，请找设备管理员进行设备归还操作！'
#SK_RETURN_DEVICE_TIP = '设备实体是否归还？'

SK_BORROW_DEVICE = '借用'
SK_REBORROW_DEVICE = '转借'
SK_BORROW_LOG = '记录'
SK_RETURN_DEVICE = '归还'
SK_OPERATEACTOR = '操作人'


#菜单项
SK_MENU_CREATE_TEAM    = '创建团队'
SK_MENU_AUTHORITY_MANAGER = '权限管理'
SK_TEAM_LAB = '团队简介'
SK_TEAM_NUMBER = '团队人数'
SK_TEAM_NAME = '团队名称'
SK_BTN_OK = '确定'
SK_BTN_SAVE = '保存'
SK_BTN_CREATE = '创建'
SK_BTN_CANCEL = '取消'
SK_BTN_CLEAR = '清除'
SK_BTN_DELETE = '删除'
SK_TEAMLABEDIT_PLACE = '在此输入团队简介信息...'
SK_ADD_PROJECT = '新建项目'
SK_ADD_NEW_TASKROW = '添加新的任务列'
SK_REMOVE_TASK_ROW = '删除面板'

#任务提醒时间菜单
SK_DAY_ONE = '一天前'
SK_DAY_TWO = '二天前'
SK_DAY_THREE = '三天前'
SK_DAY_FOUR = '四天前'
SK_DAY_FIVE = '五天前'
SK_DAY_SIX = '六天前'
SK_WEEK_ONE = '一周前'
SK_WEEK_TWO = '二周前'
SK_WEEK_THREE = '三周前'
SK_WEEK_FOUR = '四周前'

#日报查询区间
SK_DAILY_ONE = '1天内'
SK_DAILY_TWO = '2天内'
SK_DAILY_THREE = '3天内'
SK_DAILY_FOUR = '4天内'
SK_DAILY_FIVE = '5天内'
SK_DAILY_SIX = '6天内'
SK_WEEK_DAILY_ONE = '1周内'
SK_WEEK_DAILY_TWO = '2周内'
SK_WEEK_DAILY_THREE = '3周内'
SK_WEEK_DAILY_FOUR = '4周内'

#时间
SK_TIME_HOUR = '小时'
SK_TIME_DAY = '天'

SK_MAIN_TITLE = 'OKR工作方法'

#登入，注册界面
SK_LOGIN_WIN_TITLE = '登入'
SK_REGISTER_WIN_TITLE = '注册'
SK_FIND_PW_INFO = '请联系管理员找回密码！'
SK_USER_NAME = "通行账号"
SK_REGISTER_USERNAME = "注册帐号"
SK_FORGET_PW = "忘记密码"
#主界面
SK_INFO_SERACH = '信息查询'
SK_FATAL_PROPLEM = '严重问题'
SK_SELF_WORK = '个人工作台'
#message
SK_WARN = '警告'
SK_ERROR = '错误'
SK_INFO  = '提示'
SK_MESSAGE_TITLE = '提示框'
SK_USER_MANAGER = '权限管理'
SK_USER_PASSWORD_WARN = '用户名或者密码不合法，用户名为真实中文名+数字，密码大于6位！'
SK_USER_REGISTER_SUCC = '恭喜您，新的通信证注册成功！'
SK_USER_RE_REGISTER = '抱歉，新的通信证已经被注册，是否重新注册？'
SK_USER_LOGIN_FAIL = '登入失败，用户不存在或者密码错误！'
SK_MSG_NAME_LAB_IS_NULL = '名称和参与者不能为空，请补充完整！'
SK_ADD_USER_TO_TEAM_SUCC = '添加用户到团队成功！'
SK_REMOVE_TASK_ROW_WARN = '当前任务面板包含任务项，是否继续删除？'
SK_REMOVE_TASK_ROW_ERROR = '当前任务面板包含任务项，请刷新任务列表再进行操作！'
SK_REMOVE_PROJECT_TARGET_WARN = '是否确定删除此项目目标？'
SK_REMOVE_PROJECT_WARN = '是否确定删除此项目？'
SK_REMOVE_ACTOR_WARN = '是否确定删除参与者或者执行人？'
SK_CANNOT_REMOVE_ACTOR_INFO = '该执行人已经投入了工时，不能被删除！'
SK_REMOVE_TARGET_ERROR = '当前项目目标中还包含任务项，需要先删除项目目标下的所有任务才能删除项目目标！'
SK_SET_STATE_OK_ERROR = '当前目标或者任务下面还有任务或者子任务未完成，不能设置当前目标或者任务为完成状态！'
#pageProject
SK_PROJECT_WIN_TITLE = '项目创建/设置'
SK_ADD_NEW_PROJECT_SUCC = '恭喜您，新项目添加成功！'
SK_ADD_NEW_PROJECT_FAIL = '抱歉，新项目添加失败，请尝试更换项目名称重新添加！'
SK_UPDATE_PROJECT_FAIL = '抱歉，更新项目信息失败！'
SK_PROJECTLABEDIT_PLACE = '在此输入项目简介信息...'
SK_PROJECT_LAB = '项目简介'
SK_ACTOR = '参与者  '
SK_ACTOR_AUTHORITY_DATA = '权限信息'
SK_EXECUTOR = '执行人  '
SK_PROJECT_NAME = '项目名称'
SK_PROJECT_STATE = '项目状态'
SK_END_DATE = '截至日期'
SK_SET_END_DATE = '设置截至时间'
SK_NO_END_DATE = '无截至日期'
SK_NO_ACTOR_TO_ADD = '没有可以添加的用户'
SK_TASK_ACTOR_NUMS_TO_MUCH = '执行人数量已到最大人数限制，不能继续添加！'
SK_PROJECT_ACTOR_NUMS_TO_MUCH = '参与者数量已到最大人数限制，不能继续添加！'
SK_PROJECT_TARGET_NAME = '关键目标'
SK_PROJECT_TARGET_LAB = '目标说明'
SK_PROJECT_TARGET_STATE = '目标状态'
SK_ADD_NEW_TASK_WARN = '您没有添加任务的权限，请联系管理员添加相应的权限！'
SK_TARGET_WIN_TITLE = '目标信息'
SK_ADD_NEW_TARGET_WARN = '您没有添加项目目标的权限，请联系管理员添加相应的权限！'
SK_ADD_NEW_TARGET_ERROR = '目标名称和目标简介不能为空，请补充完整！！'
SK_ADD_NEW_PROJECT_TARGET_SUCC = '恭喜您，新项目关键目标添加成功！'
SK_ADD_NEW_PROJECT_TARGET_FAIL = '抱歉，新项目关键目标添加失败，请尝试更换项目关键目标名称重新添加，或者当前项目已经被删除！'
SK_ADD_NEW_PROJECT_WARN = '您没有添加新项目的权限，请联系管理员添加相应的权限！'
SK_EDIT_PROJECT_WARN = '您没有设置项目的权限，请联系管理员添加相应的权限！'

SK_COPY_CURTASK = '拷贝任务'
SK_COPY_CURTARGET = '拷贝目标'
SK_COPY_CURSUBTASK = '拷贝子任务'
SK_PASTE_TASK = '粘贴任务'
#状态相关的翻译
#項目，目標，任務狀態
SK_STATE_UNOK = '未完成'
SK_STATE_INIT = '未开始'
SK_STATE_OK = '已完成'
SK_STATE_STOP = '中止'
SK_STATE_DELAY = '延期'

#任务相关翻译
SK_TASK_WIN_TITLE = '任务信息'
SK_TASK_STATE = '任务状态'
SK_TASK_REMIND = '任务提醒'
SK_TASK_REMIND_STATE = '不提醒'
SK_TASK_LAB =  '任务备注'
SK_DEFAULT_TASK_LAB = '还没有任务备注，在此处添加备注...'
SK_DEL_TASK_WARN = '删除任务后不能恢复，是否现在删除当前任务？'
SK_ADD_TASK_ROW_WARN = '已经存在相同名称的任务列，请修改成其他名称再添加！'
SK_ADD_TASK_ROW_EMPTY_WARN = '任务列名称不能为空！'
SK_DAILY_DATA = '日报信息'
SK_TASK_TIME_ALL = '总耗时'
SK_PROJECT_SETTING = "项目设置"
SK_PROJECT_SHOW_MODE = "查看方式"
SK_PROJECT_TABLE_MODE = '表格'
SK_PROJECT_KAN_MODE = '看板'
SK_PROJECT_CREATE_DATE = '创建时间: '
SK_PROJECT_FILTER_SETTING = "筛选设置"
SK_PROJECT_FRESH = "刷新项目"
SK_DAILY_SEARCH = "日报查询"
SK_PROJECT_EXPORT = "项目导出"
SK_DEVICE_MANAGER = "设备管理"
SK_ALL_PROJECT = '所有项目'
SK_TASK_ROW_UNSTART = '未开始'
SK_TASK_ROW_DOING = '进行中'
SK_TASK_ROW_END = '已完成'

#日报相关
SK_DAILY_SEARCH_WIN_TITLE = '日报查询'
SK_DAILY_WIN_TITLE = '日报创建/修改'
SK_DAILY_CREATE_WARN = '今日进展、明日计划和日报日期不能为空！'
SK_DAILY_CREATE_TASKTIME_WARN = '今日进展不为‘无’，工时投入不能为0，请选择投入的工时数！'
SK_DAILY_TASK_TIME = '工时'
SK_DAILY_DATE = '日报日期'
SK_DAILY_ACTOR = '填写人'
SK_DAILY_YESTERDAY_PLAN = "昨日计划"
SK_DAILY_TODAY_MARCH = '今日进展'
SK_DAILY_PLAN_SUCC = '计划达成'
SK_DAILY_PLAN_FAIL_REASON = '未达成说明'
SK_DAILY_PLAN_TOMORROW = '明日计划'
SK_DAILY_HELP_DATA = '困难与求助'
SK_DAILY_TASK = '任务信息'
SK_SET_DAILY_DATE = '设置日报日期'
SK_SEARCH_USER_NUMS_TO_MUCH = '日报查询人数已到最大人数限制，不能继续添加！'
SK_SAME_DAILY_DATE_WARN = '当前任务已经存在了当前日期的日报，请重新选择日报日期！'
SK_TODAY_DAILY_WARN = '当天的日报只能在下班时间({})后才能填写，！'
SK_ALL_TASKTIME_ONEDAY_TOMUCH_WARN = '当天的日报累计工时为{}小时，继续添加工时为{}小时的日报后当日总工时将超过{}小时，是否继续添加日报？'
SK_ALL_ACTOR = '所有人'
SK_SEARCH_DAILY_ACTOR_TIP = '选择查询人员'

SK_FOLD_BY_TARGET = '目标'
SK_FOLD_BY_TASK = '一级任务'
SK_FOLD_BY_SUBTASK = '二级任务'

SK_0_HOUR = '0小时'
SK_0_5_HOUR = '0.5小时'
SK_1_HOUR = '1小时'
SK_1_5_HOUR = '1.5小时'
SK_2_HOUR = '2小时'
SK_2_5_HOUR = '2.5小时'
SK_3_HOUR = '3小时'
SK_3_5_HOUR = '3.5小时'
SK_4_HOUR = '4小时'
SK_4_5_HOUR = '4.5小时'
SK_5_HOUR = '5小时'
SK_5_5_HOUR = '5.5小时'
SK_6_HOUR = '6小时'
SK_6_5_HOUR = '6.5小时'
SK_7_HOUR = '7小时'
SK_7_5_HOUR = '7.5小时'
SK_8_HOUR = '8小时'
SK_8_5_HOUR = '8.5小时'
SK_9_HOUR = '9小时'
SK_9_5_HOUR = '9.5小时'
SK_10_HOUR = '10小时'
SK_10_5_HOUR = '10.5小时'
SK_11_HOUR = '11小时'
SK_11_5_HOUR = '11.5小时'
SK_12_HOUR = '12小时'
SK_12_5_HOUR = '12.5小时'
SK_13_HOUR = '13小时'
SK_13_5_HOUR = '13.5小时'
SK_14_HOUR = '14小时'
SK_14_5_HOUR = '14.5小时'
SK_15_HOUR = '15小时'
SK_15_5_HOUR = '15.5小时'
SK_16_HOUR = '16小时'

SK_TARGET_OK = '是'
SK_TARGET_UNOK = '否'
SK_TARGET_NODEAL = '不涉及'

#用户
SK_USER_HELLO = ",您好！"
SK_USER_QUIT = '退出登入'

#表头翻译
SK_TITLE = '标题'
SK_TIME = '结束时间'
SK_STATE = '状态'
SK_ACTOR = '参与者'
SK_PARENT_TASK = '父任务'
SK_LAB = '备注'

#设备表头翻译
SK_NAME = '设备名'
SK_NUMBER = '设备序列号'
SK_BORROWACTOR = '借用人'
SK_BORROWDATE= '借用时间'
SK_OPERATE = '操作'


#项目导出
SK_TARGET_HEAD = '目标'
SK_TARGET_DATE_HEAD = '目标时间'
SK_TASK_HEAD = '关键结果'
SK_TASK_DATE_HEAD = '结束时间'
SK_TASK_STATE_HEAD = '状态'
SK_TASK_ACTOR_HEAD = '负责人'
SK_SUB_TASK_HEAD = '子任务'
SK_SUB_TASK_DATE_HEAD = '结束时间'
SK_SUB_TASK_STATE_HEAD = '状态'
SK_SUB_TASK_ACTOR_HEAD = '负责人'
SK_ALL_STATE = '所有状态'

SK_PROJECT_EXPORT_SUCC_INFO = '恭喜，项目数据导出成功，是否继续导出项目数据？'

